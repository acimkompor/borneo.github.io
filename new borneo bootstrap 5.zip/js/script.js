const navbarMenu = document.getElementsByClassName("nav-link");
